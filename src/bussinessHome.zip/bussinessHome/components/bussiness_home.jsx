import React from "react";
import "../styles/bussiness_home.css";
function Home() {
  return (
    <div id="home">
      <div className="allmain">
        <div className="buss_main">
          <div className="bussiness_header">
            <h1 className="buss_h1">Introducing </h1>
            <h2 className="buss_h2">
              <span className="buss_span">FitBet </span> For Bussiness
            </h2>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Home;
